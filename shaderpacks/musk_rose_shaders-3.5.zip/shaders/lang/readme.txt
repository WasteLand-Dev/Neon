For those who wants to translate the options.
Since I only know Japanese, English, and a little bit of Korean, thank you very, very much; I appreciate your willingness!
You can send pull request on GitHub: https://github.com/Rinloid/musk_rose_je